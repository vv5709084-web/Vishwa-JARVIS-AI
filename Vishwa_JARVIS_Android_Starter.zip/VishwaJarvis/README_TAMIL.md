# Vishwa JARVIS – Android Starter

இது JARVIS Android App-ன் முதல் source-code prototype.

## இப்போது உள்ள வசதிகள்
- Futuristic dark JARVIS-style screen
- தமிழ் Speech-to-Text (Android SpeechRecognizer)
- Android Text-to-Speech
- Chat-style interface

## இன்னும் சேர்க்க வேண்டியவை
- உண்மையான AI brain / LLM API
- Secure backend (API key-ஐ Android app-ல் hard-code செய்யக்கூடாது)
- Internet search integration
- User-approved Android actions
- Proper app icon, tests, release signing

## APK build செய்வது
1. கணினியில் Android Studio நிறுவவும்.
2. இந்த project folder-ஐ Android Studio-வில் Open செய்யவும்.
3. Gradle sync முடியும் வரை காத்திருக்கவும்.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) தேர்வு செய்யவும்.
5. APK உருவானதும் Android Studio காட்டும் `locate` வழியாகக் கண்டுபிடித்து மொபைலில் install செய்யவும்.

இந்த ZIP ஒரு source project மட்டுமே; APK ஏற்கெனவே build செய்யப்பட்டதாகக் கருத வேண்டாம்.
