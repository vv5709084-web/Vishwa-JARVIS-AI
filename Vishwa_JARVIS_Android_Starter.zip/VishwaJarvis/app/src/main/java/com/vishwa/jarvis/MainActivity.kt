package com.vishwa.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.util.Locale

data class ChatLine(val speaker: String, val message: String)

class MainActivity : ComponentActivity() {
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { result ->
            if (result == TextToSpeech.SUCCESS) tts?.language = Locale("ta", "IN")
        }
        setContent {
            JarvisApp(
                onListen = { success, failure -> listen(success, failure) },
                onSpeak = { text -> tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis") }
            )
        }
    }

    private fun listen(success: (String) -> Unit, failure: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            failure("இந்த சாதனத்தில் Speech Recognition சேவை கிடைக்கவில்லை.")
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { failure("குரலைப் பெற முடியவில்லை. மீண்டும் முயற்சி செய். (Code $error)") }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text.isNullOrBlank()) failure("குரல் கிடைக்கவில்லை.") else success(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ta-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS கேட்கிறது...")
        }
        speechRecognizer?.startListening(intent)
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun JarvisApp(onListen: ((String) -> Unit, (String) -> Unit) -> Unit, onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    var typedText by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("தயார் • READY") }
    var listening by remember { mutableStateOf(false) }
    val chat = remember { mutableStateListOf(ChatLine("JARVIS", "வணக்கம்! நான் Vishwa JARVIS. என்ன உதவி வேண்டும்?")) }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            listening = true
            status = "கேட்கிறேன்..."
            onListen(
                { spoken -> typedText = spoken; listening = false; status = "குரல் பெறப்பட்டது" },
                { error -> listening = false; status = error }
            )
        } else status = "Microphone permission மறுக்கப்பட்டது. Settings-ல் Allow செய்யவும்."
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Column(
            Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF07182B), Color(0xFF020711))))
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(18.dp))
            Text("VISHWA", color = Color(0xFF5ADFFF), fontWeight = FontWeight.Bold)
            Text("J.A.R.V.I.S", color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold)
            Text("PERSONAL AI ASSISTANT", color = Color(0xFF8BAFC8), style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(24.dp))
            Box(
                Modifier.size(142.dp).background(
                    Brush.radialGradient(listOf(Color(0xFF36C8F5), Color(0xFF103D60), Color.Transparent)),
                    CircleShape
                ),
                contentAlignment = Alignment.Center
            ) {
                Box(Modifier.size(82.dp).background(Color(0xFF0A2944), CircleShape), contentAlignment = Alignment.Center) {
                    Text("AI", color = Color(0xFF7CE7FF), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(status, color = Color(0xFF9ADCF4), style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(16.dp))

            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(chat) { line ->
                    val isJarvis = line.speaker == "JARVIS"
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isJarvis) Arrangement.Start else Arrangement.End) {
                        Surface(
                            color = if (isJarvis) Color(0xFF102B43) else Color(0xFF07577A),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(Modifier.padding(12.dp)) {
                                Text(line.speaker, color = Color(0xFF62D9FF), style = MaterialTheme.typography.labelSmall)
                                Text(line.message, color = Color.White)
                            }
                        }
                    }
                }
            }

            OutlinedTextField(
                value = typedText, onValueChange = { typedText = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("JARVIS-ிடம் கேள்...") },
                singleLine = true
            )
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    modifier = Modifier.weight(1f),
                    onClick = {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            listening = true
                            status = "கேட்கிறேன்..."
                            onListen(
                                { spoken -> typedText = spoken; listening = false; status = "குரல் பெறப்பட்டது" },
                                { error -> listening = false; status = error }
                            )
                        } else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    }
                ) { Text(if (listening) "கேட்கிறேன்..." else "🎙 Voice") }

                Button(
                    modifier = Modifier.weight(1f),
                    onClick = {
                        val question = typedText.trim()
                        if (question.isNotEmpty()) {
                            chat.add(ChatLine("YOU", question))
                            val reply = "உன் கேள்வி கிடைத்தது: $question. இது ஆரம்ப Prototype. அடுத்த கட்டத்தில் பாதுகாப்பான AI சேவையை இணைப்போம்."
                            chat.add(ChatLine("JARVIS", reply))
                            onSpeak(reply)
                            typedText = ""
                            status = "தயார் • READY"
                        }
                    }
                ) { Text("Send ➤") }
            }
            Spacer(Modifier.height(10.dp))
            Text("Prototype 1.0 • AI API இன்னும் இணைக்கப்படவில்லை", color = Color(0xFF7896AD), style = MaterialTheme.typography.labelSmall)
        }
    }
}
